SAKURA LIFE 🌸

Abra sakura-life.html em um navegador moderno (Chrome, Edge, Firefox ou Safari).
Os dados são gravados automaticamente no IndexedDB do navegador e ficam neste dispositivo/perfil.
Use Configurações > Exportar backup para criar uma cópia JSON. Para restaurar, use Importar backup.

Observações:
- O armazenamento local não sincroniza entre dispositivos e pode ser apagado se os dados do navegador forem removidos.
- A fonte decorativa é carregada do Google Fonts quando houver internet; o app funciona sem ela usando fontes alternativas.
- O Pomodoro funciona enquanto a página estiver aberta.
